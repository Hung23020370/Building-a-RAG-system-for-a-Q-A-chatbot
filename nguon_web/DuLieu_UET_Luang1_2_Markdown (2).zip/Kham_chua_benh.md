Bệnh viện Đại học Quốc gia Hà Nội (Hospital of Vietnam National University, Hanoi - tên viết tắt VNU Hospital) được thành lập từ năm 2011 và đang trong quá trình xây dựng cơ sở vật chất, đầu tư trang thiết bị. Bệnh viện Đại học Quốc gia Hà Nội là một trong các Bệnh viện đại học, mô hình mới về đào tạo, nghiên cứu kết hợp với cung cấp dịch vụ y tế chất lượng cao đáp ứng nhu cầu xã hội, thuộc hệ thống khám chữa bệnh của Bộ Y tế.

Việc khám chữa bệnh ngoại trú (bao gồm cả khám bảo hiểm và dịch vụ), khám sức khỏe định kỳ, khám cấp giấy chứng nhận sức khỏe cho các đơn vị trong nước và người nước ngoài được Bệnh viện giao cho Phòng khám đa khoa 182 Lương Thế Vinh (Phòng khám trực thuộc Bệnh viện). Hiện nay, Phòng khám Đa khoa 182 Lương Thế Vinh phục vụ chăm sóc sức khỏe cho hơn 45.000 Cán bộ, Giảng viên, Học sinh, Sinh viên trong hệ thống ĐHQGHN và khu vực dân cư lân cận. Phòng khám Đa khoa 182 Lương Thế Vinh có tư cách pháp nhân, con dấu và tài khoản riêng và giao cho Bệnh viện ĐHQGHN quản lý. Ngày 22/07/2013, Bộ y tế đã thẩm định, cấp phép hoạt động khám, chữa bệnh theo Giấy phép số 02/BYT-GPHĐ; và phê duyệt danh mục 494 kỹ thuật chuyên môn đối với Phòng khám đa Khoa 182 Lương Thế Vinh trực thuộc ĐHQGHN theo Quyết định số 2631/QĐ-BYT ngày 22/07/2013 của Bộ trưởng Bộ y tế.

Việc khám sức khỏe của sinh viên mới nhập học, sinh viên chuẩn bị tốt nghiệp và khám chữa bệnh của sinh viên trong ĐHQGHN nói chung và sinh viên Trường Đại học Công nghệ nói riêng sẽ được thực hiện tại Bệnh viện ĐHQGHN.

Thông tin liên quan đến bảo hiểm y tế, bảo hiểm thân thể, thủ tục khám chữa bệnh và thanh toán quyền lợi bảo hiểm, sinh viên liên hệ với phòng CTSV theo số ĐT: [024 3754 8864](tel:02437548864) hoặc cô Bùi Thị Thu Hương theo email: [huongbtt@vnu.edu.vn](mailto:huongbtt@vnu.edu.vn).

Cơ sở 1: Phòng khám đa khoa 182 Lương Thế Vinh

Địa chỉ: 182 Lương Thế Vinh, Thanh Xuân, Hà Nội

Số điện thoại: [0243 554 4833](tel:02435544833)

Cơ sở 2: Cơ sở khám chữa bệnh Phạm Văn Đồng

Địa chỉ: Số 2 Phạm Văn Đồng, Cầu Giấy, Hà Nội

Số điện thoại: [0243 754 9559](tel:02437549559)

Chi tiết xem tại: <http://bvdhqghn.vn/>