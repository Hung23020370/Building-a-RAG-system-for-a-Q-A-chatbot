## 1, Quy chế đào tạo

[Bản đầy đủ (K66 trở về trước)](https://vnu.edu.vn/upload/vanban/2014/12/29/Final_QC-dH-_2014_Ban-hanh-25-12-2014.pdf) [Bản tóm tắt bằng hình ảnh (K66 trở về trước)](https://vnu.edu.vn/ttsk/?C1654/N26960/%5bInfographic%5d-Quy-che-dao-tao-tai-dai-hoc-Quoc-gia-Ha-Noi.htm) [Quy chế đào tạo ĐH năm 2022 (K67 trở đi)](https://uet.vnu.edu.vn/wp-content/uploads/2022/12/Quy-ch%E1%BA%BF-%C4%90T%C4%90H-3626.pdf)

## 2, Quy chế công tác sinh viên

[Bản đầy đủ](https://vnu.edu.vn/upload/vanban/2018/11/01/Quy-che-32-ngay-05-1-2017-Quy-che-Cong-tac-sinh-vien-tai-Dai-hoc-Quoc-gia-Ha-Noi.PDF) [Bản tóm tắt bằng hình ảnh](https://vnu.edu.vn/ttsk/?C1654/N26956/%5bInfographic%5d-Quy-che-cong-tac-sinh-vien-tai-dai-hoc-Quoc-gia-Ha-Noi.htm) [Bản tóm tắt bằng giọng nói](https://services.uet.vnu.edu.vn/books/QuyCheSinhVien/)

## 3, Quy chế xét thi đua khen thưởng

[Bản đầy đủ](./../Quy dinh khen thuong tai Truong DHCN 2023.pdf) [Bổ sung điều chỉnh](./../Signed.Dieu chinh quy dinh khen thuong 2025.pdf)