Thực tập môn học bắt buộc: Khi sinh viên vào học chuyên ngành, tùy theo từng Khoa/Viện/Bộ môn sẽ có những môn học yêu cầu đi thực tập tại doanh nghiệp hoặc tại xưởng, sinh viên theo dõi các thông báo từ Khoa/Viện/Bộ môn để đăng ký và thực hiện theo lịch được sắp xếp.

Thực tập theo nhu cầu của Doanh nghiệp: Khi các doanh nghiệp có nhu cầu tuyển thực tập, Nhà trường và các Khoa sẽ gửi thông tin cho sinh viên biết và lựa chọn đăng ký, với hình thức này sinh viên phải chủ động sắp xếp về mặt thời gian và không để ảnh hưởng đến kết quả học tập.

## Sinh viên theo dõi thông tin trên Page của Phòng CTSV:

<https://www.facebook.com/PhongCTSV.DHCN.VNU>

## Hoặc tại Cổng thông tin làm việc của Nhà trường

<https://vieclam.uet.vnu.edu.vn/>