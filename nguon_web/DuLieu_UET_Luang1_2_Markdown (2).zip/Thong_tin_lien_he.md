1) Phòng Đào tạo:

Phòng 105 – Nhà E3.

Email: [daotao\_dhcn@vnu.edu.vn](mailto:daotao_dhcn@vnu.edu.vn)

Điện thoại: [(024) 3202 6858](tel:02432026858)

2) Phòng Công tác sinh viên:

Phòng 104 – Nhà E3.

Email: [ctsv\_dhcn@vnu.edu.vn](mailto:ctsv_dhcn@vnu.edu.vn)

Điện thoại cơ sở Xuân Thủy: [(024) 3754 8864](tel:02437548864)

Điện thoại cơ sở Hòa Lạc:     [0886 241 976](tel:02437548864)

<https://www.facebook.com/PhongCTSV.DHCN.VNU>

3) Phòng Kế hoạch Tài chính:

Phòng 101 – Nhà E3.

Điện thoại: [(024) 3754 9401](tel:02437549401)

4) Trung tâm Đại học số:

Nhà G2B, 144 Xuân Thủy, Cầu Giấy, Hà Nội.

Điện thoại: [(024) 3754 7463](tel:02437547463)

Website: <http://ccne.uet.vnu.edu.vn/>

5) Khoa Công nghệ thông tin:

Địa chỉ: Phòng 301 – Nhà E3, 144 Xuân Thủy, Cầu Giấy, Hà Nội.

Điện thoại: [(024) 3754 7064](tel:02437547064)

Website: <http://fit.uet.vnu.edu.vn/>

6) Khoa Điện tử viễn thông:

Địa chỉ: Phòng 205-Nhà G2, 144 Xuân Thủy, Cầu Giấy, Hà Nội.

Điện thoại: [(024) 3754 9338](tel:02437549338 ) Fax: [(024) 3754 9338](tel:02437549338)

Email: [dtvt@vnu.edu.vn](mailto:dtvt@vnu.edu.vn)

7) Khoa Cơ học kỹ thuật và Tự động hóa:

Cơ sở 1: Phòng 311, Nhà G2, 144 Xuân Thủy, Cầu Giấy, Hà Nội

Cơ sở 2: Tầng 4, 5 – Nhà C, Viện Cơ học số 264 Đội Cấn, Ba Đình, Hà Nội.

Website: <http://fema.uet.vnu.edu.vn/>

Điện thoại: [(024) 3754 9431](tel:02437549431)

8) Khoa Vật lý kỹ thuật và Công nghệ nano:

Địa chỉ: Phòng 2.2 – Nhà E4, 144 Xuân Thủy, Cầu Giấy, Hà Nội.

Điện thoại: [(024) 3754 9429](tel:02437549429)

Email: [vlkt-cnnn@vnu.edu.vn](mailto:vlkt-cnnn@vnu.edu.vn)

Website: <http://fepn.uet.vnu.edu.vn/>

9) Khoa Công nghệ nông nghiệp:

Phòng 312, Nhà G2, 144 Xuân Thủy, Cầu Giấy, Hà Nội.

Website: <http://www.fat.uet.vnu.edu.vn/>

Điện thoại: [(024) 3212 3709](tel:02432123709)

10) Viện Công nghệ hàng không vũ trụ:

Địa chỉ: Phòng 314 – Nhà G2 – 144 Xuân Thủy – Cầu Giấy – Hà Nội.

Điện thoại: [(024) 3754 9337](tel:02437549337)

Điện thoại: [(024) 3754 9337](tel:02437549337)

Email: [sae@vnu.edu.vn](mailto:sae@vnu.edu.vn)

Website: <http://sae.uet.vnu.edu.vn/>

11) Khoa Công nghệ xây dựng – giao thông:

Địa chỉ: Phòng 710, Nhà E3, 144 Xuân Thủy, Cầu Giấy, Hà Nội.

Điện thoại: [(024) 3227 2837](tel:02432272837)

Website Khoa: <http://cte.uet.vnu.edu.vn>

Website PTN: <http://amslab.uet.vnu.edu.vn>

12) Viện Trí tuệ nhân tạo

Địa chỉ: Phòng 315, Nhà G2, 144 Xuân Thủy, Cầu Giấy, Hà Nội

Điện thoại: [(+84) 098 725 1295](tel:0987251295)

Website Viện: <https://uet.vnu.edu.vn/category/vien-tri-tue-nhan-tao/>