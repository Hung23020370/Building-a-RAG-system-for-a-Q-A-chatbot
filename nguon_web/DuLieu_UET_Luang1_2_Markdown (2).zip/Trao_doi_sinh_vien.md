Hàng năm sẽ có nhiều chương trình hợp tác, trao đổi sinh viên trong nước và quốc tế. Sinh viên theo dõi trên Website của nhà trường (mục Sinh viên/Thông báo) để biết thông tin và nộp hồ sơ.

## Sinh viên theo dõi thông tin trên Page của Phòng CTSV:

<https://www.facebook.com/PhongCTSV.DHCN.VNU>

## Hoặc tại Website của nhà trường:

<https://uet.vnu.edu.vn/category/sinh-vien/giao-luu-trao-doi-sinh-vien/>