1. Trung tâm Thư viện và Tri thức số là cơ sở hợp nhất các thư viện của các trường đại học thuộc ĐHQGHN, được sử dụng chung cho tất cả sinh viên các trường. Tại đây, sinh viên có thể sử dụng thẻ sinh viên để liên hệ để mượn sách, giáo trình và các tài liệu tham khảo khác. Ngoài ra, sinh viên có thể truy cập vào Website: <https://lic.vnu.edu.vn/>, đăng nhập bằng tài khoản Email do nhà trường cấp để tìm đọc các tài liệu trên nền tảng số.

Địa chỉ: Tòa nhà C1T, ĐHQGHN, 144 Xuân Thủy

ĐT: [024 3754 6545](tel:02437546545)

Email: [lic@vnu.edu.vn](mailto:lic@vnu.edu.vn)

2. Phòng đọc, thư viện Hội sinh viên: Là phòng đọc do CLB Thư viện của Hội sinh viên Trường ĐH Công nghệ tổ chức. Tại đây, sinh viên có thể liên hệ để mượn các loại giáo trình, sách tham khỏa, luận văn, luận án.

Địa chỉ: Phòng 201, 202 GDD3, số 8 Tôn Thất Thuyết

Thời gian: sáng từ 8h-11h, chiều từ 14h-17h các ngày từ thứ Hai đến thứ Sáu

ĐT: [024 3754 7528](tel:02437547528) (Văn phòng đoàn)

Email: [thuvienhsv.uet@gmail.com](mailto:thuvienhsv.uet@gmail.com)